"""Python Cookbook

Chapter 12, recipe 6 -- client.
"""

import urllib.request
import urllib.parse
import json

if __name__ == "__main__":

    # 1. Validate and get the OpenAPI specification.

    try:
        from swagger_spec_validator import validate_spec_url
        validate_spec_url('http://127.0.0.1:5000/dealer/swagger.json')
        print("swagger.json is valid")
    except ImportError as ex:
        pass

    swagger_request = urllib.request.Request(
        url = 'http://127.0.0.1:5000/dealer/swagger.json',
        method = "GET",
        headers = {
            'Accept': 'application/json',
        }
    )

    from pprint import pprint
    with urllib.request.urlopen('http://127.0.0.1:5000/dealer/swagger.json') as response:
        swagger = json.loads(response.read().decode("utf-8"))
        print(swagger)

    # 2. Post to create a player.

    full_url = urllib.parse.ParseResult(
        scheme="http",
        netloc="127.0.0.1:5000",
        path="/dealer" + "/players",
        params=None,
        query=None,
        fragment=None
    )

    document = {
        'name': 'Xander Bowers',
        'email': 'x@example.com',
        'year': 1985,
        'twitter': 'https://twitter.com/PacktPub'
    }

    request = urllib.request.Request(
        url = urllib.parse.urlunparse(full_url),
        method = "POST",
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json;charset=utf-8',
        },
        data = json.dumps(document).encode('utf-8')
    )

    try:
        with urllib.request.urlopen(request) as response:
            # print(response.status)
            assert response.status == 201
            print(response.headers)
            document = json.loads(response.read().decode("utf-8"))

        print(document)
        assert document['status'] == 'ok'
        id = document['id']
    except urllib.error.HTTPError as ex:
        print(ex.status)
        print(ex.headers)
        print(ex.read())

    # 3. GET to see the players.

    from pprint import pprint
    full_url = urllib.parse.ParseResult(
        scheme="http",
        netloc="127.0.0.1:5000",
        path="/dealer" + "/players",
        params=None,
        query=None,
        fragment=None
    )

    request = urllib.request.Request(
        url = urllib.parse.urlunparse(full_url),
        method = "GET",
        headers = {
            'Accept': 'application/json',
        }
    )

    with urllib.request.urlopen(request) as response:
        assert response.status == 200
        # print(response.headers)
        players = json.loads(response.read().decode("utf-8"))

    pprint(players)

    # 4. GET to see a specific player.

    id = '75f1bfbda3a8492b74a33ee28326649c'
    full_url = urllib.parse.ParseResult(
        scheme="http",
        netloc="127.0.0.1:5000",
        path="/dealer" + "/players/{id}".format(id=id),
        params=None,
        query=None,
        fragment=None
    )

    request = urllib.request.Request(
        url = urllib.parse.urlunparse(full_url),
        method = "GET",
        headers = {
            'Accept': 'application/json',
        }
    )

    from urllib.error import HTTPError
    try:
        with urllib.request.urlopen(request) as response:
            print(response.status)
            print(response.headers)
            print(json.loads(response.read().decode("utf-8")))
    except HTTPError as ex:
        print(ex.status)
        print(ex.read())
